
#define _GNU_SOURCE
#include <arpa/inet.h>
#include <errno.h>
#include <linux/in6.h>
#include <netinet/icmp6.h>
#include <netinet/ip6.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

static void put_addr(uint8_t *dst, uint8_t tag)
{
	for (size_t i = 0; i < 16; i++)
		dst[i] = (uint8_t)(tag + i);
}

static unsigned long arg_ul(int argc, char **argv, int idx, unsigned long def)
{
	char *end = NULL;
	unsigned long v;

	if (argc <= idx)
		return def;
	errno = 0;
	v = strtoul(argv[idx], &end, 0);
	if (errno || !end || *end)
		return def;
	return v;
}

int main(int argc, char **argv)
{
	unsigned long segments_left = arg_ul(argc, argv, 1, 255);
	unsigned long payload_len = arg_ul(argc, argv, 2, sizeof(struct icmp6_hdr));
	unsigned long pad_ext_len = arg_ul(argc, argv, 3, 0);
	const char *src_addr = argc > 4 ? argv[4] : "2001:db8::1";
	const char *dst_addr = argc > 5 ? argv[5] : "2001:db8::2";
	size_t rthdr_off;
	size_t payload_off;
	size_t packet_len;
	struct sockaddr_in6 sin6;
	struct ip6_hdr *ip6;
	uint8_t *packet;
	uint8_t *rh;
	int fd;
	int one = 1;
	ssize_t ret;

	if (segments_left > 255)
		segments_left = 255;
	if (payload_len < sizeof(struct icmp6_hdr))
		payload_len = sizeof(struct icmp6_hdr);
	if (payload_len > 8192)
		payload_len = 8192;
	if (pad_ext_len > 1024)
		pad_ext_len = 1024;
	pad_ext_len = (pad_ext_len + 7) & ~7UL;
	if (pad_ext_len && pad_ext_len < 8)
		pad_ext_len = 8;

	rthdr_off = 40 + pad_ext_len;
	payload_off = rthdr_off + 8 + 16;
	packet_len = payload_off + payload_len;
	packet = calloc(1, packet_len);
	if (!packet) {
		perror("calloc");
		return 1;
	}

	ip6 = (struct ip6_hdr *)packet;
	rh = packet + rthdr_off;
	ip6->ip6_flow = htonl(6U << 28);
	ip6->ip6_plen = htons((uint16_t)(packet_len - 40));
	ip6->ip6_nxt = pad_ext_len ? IPPROTO_DSTOPTS : IPPROTO_ROUTING;
	ip6->ip6_hlim = 64;
	if (inet_pton(AF_INET6, src_addr, &ip6->ip6_src) != 1 ||
	    inet_pton(AF_INET6, dst_addr, &ip6->ip6_dst) != 1) {
		perror("inet_pton");
		free(packet);
		return 1;
	}

	if (pad_ext_len) {
		uint8_t *dest = packet + 40;

		dest[0] = IPPROTO_ROUTING;
		dest[1] = (uint8_t)((pad_ext_len / 8) - 1);
		memset(dest + 2, 0, pad_ext_len - 2);
	}

	rh[0] = IPPROTO_ICMPV6;
	rh[1] = 2;
	rh[2] = 0;
	rh[3] = (uint8_t)segments_left;
	put_addr(rh + 8, 0x40);

	memset(packet + payload_off, 0x5a, payload_len);
	((struct icmp6_hdr *)(packet + payload_off))->icmp6_type = ICMP6_ECHO_REQUEST;
	((struct icmp6_hdr *)(packet + payload_off))->icmp6_id = htons(0x4848);
	((struct icmp6_hdr *)(packet + payload_off))->icmp6_seq = htons(1);

	fd = socket(AF_INET6, SOCK_RAW | SOCK_CLOEXEC, IPPROTO_RAW);
	if (fd < 0) {
		perror("socket");
		free(packet);
		return 1;
	}
	if (setsockopt(fd, IPPROTO_IPV6, IPV6_HDRINCL, &one, sizeof(one)) < 0) {
		perror("setsockopt IPV6_HDRINCL");
		close(fd);
		free(packet);
		return 1;
	}

	memset(&sin6, 0, sizeof(sin6));
	sin6.sin6_family = AF_INET6;
	sin6.sin6_port = htons(IPPROTO_ICMPV6);
	if (inet_pton(AF_INET6, dst_addr, &sin6.sin6_addr) != 1) {
		perror("inet_pton dst");
		close(fd);
		free(packet);
		return 1;
	}

	ret = sendto(fd, packet, packet_len, 0,
		     (struct sockaddr *)&sin6, sizeof(sin6));
	if (ret < 0) {
		fprintf(stderr, "sendto failed: %s\n", strerror(errno));
		close(fd);
		free(packet);
		return 1;
	}

	printf("sent 1 x %zd-byte IPv6 packet src=%s dst=%s rh_off=%zu payload=%lu pad_ext=%lu segments_left=%lu\n",
	       ret, src_addr, dst_addr, rthdr_off, payload_len,
	       pad_ext_len, segments_left);
	close(fd);
	free(packet);
	return 0;
}
