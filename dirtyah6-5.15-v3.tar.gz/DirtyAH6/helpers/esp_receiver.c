
#define _GNU_SOURCE
#include <arpa/inet.h>
#include <errno.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>
#include <linux/xfrm.h>
#include <netinet/in.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

#ifndef UDP_ENCAP
#define UDP_ENCAP 100
#endif
#ifndef UDP_ENCAP_ESPINUDP
#define UDP_ENCAP_ESPINUDP 2
#endif
#ifndef SOL_UDP
#define SOL_UDP 17
#endif
#ifndef UDP_NO_CHECK6_RX
#define UDP_NO_CHECK6_RX 102
#endif

#define ENC_PORT 4500

static void die(const char *what)
{
	fprintf(stderr, "%s: %s\n", what, strerror(errno));
	exit(1);
}

static void put_attr(struct nlmsghdr *nlh, int type, const void *data, size_t len)
{
	struct rtattr *rta = (struct rtattr *)((char *)nlh + NLMSG_ALIGN(nlh->nlmsg_len));

	rta->rta_type = type;
	rta->rta_len = RTA_LENGTH(len);
	memcpy(RTA_DATA(rta), data, len);
	nlh->nlmsg_len = NLMSG_ALIGN(nlh->nlmsg_len) + RTA_ALIGN(rta->rta_len);
}

static int add_xfrm_sa(const char *src, const char *dst, uint32_t spi)
{
	int sk = socket(AF_NETLINK, SOCK_RAW, NETLINK_XFRM);
	struct sockaddr_nl nl;
	char buf[4096];
	struct nlmsghdr *nlh;
	struct xfrm_usersa_info *xs;
	char rbuf[4096];
	ssize_t n;

	if (sk < 0)
		return -1;
	memset(&nl, 0, sizeof(nl));
	nl.nl_family = AF_NETLINK;
	if (bind(sk, (struct sockaddr *)&nl, sizeof(nl)) < 0)
		goto fail;

	memset(buf, 0, sizeof(buf));
	nlh = (struct nlmsghdr *)buf;
	nlh->nlmsg_type = XFRM_MSG_NEWSA;
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_ACK;
	nlh->nlmsg_pid = (uint32_t)getpid();
	nlh->nlmsg_seq = 1;
	nlh->nlmsg_len = NLMSG_LENGTH(sizeof(*xs));
	xs = (struct xfrm_usersa_info *)NLMSG_DATA(nlh);
	if (inet_pton(AF_INET6, dst, &xs->id.daddr.a6) != 1 ||
	    inet_pton(AF_INET6, src, &xs->saddr.a6) != 1 ||
	    inet_pton(AF_INET6, dst, &xs->sel.daddr.a6) != 1 ||
	    inet_pton(AF_INET6, src, &xs->sel.saddr.a6) != 1)
		goto fail;
	xs->family = AF_INET6;
	xs->sel.family = AF_INET6;
	xs->sel.prefixlen_d = 128;
	xs->sel.prefixlen_s = 128;
	xs->id.spi = htonl(spi);
	xs->id.proto = IPPROTO_ESP;
	xs->mode = XFRM_MODE_TRANSPORT;
	xs->replay_window = 0;
	xs->reqid = 0x1234;
	xs->lft.soft_byte_limit = (uint64_t)-1;
	xs->lft.hard_byte_limit = (uint64_t)-1;
	xs->lft.soft_packet_limit = (uint64_t)-1;
	xs->lft.hard_packet_limit = (uint64_t)-1;
	{
		char alg_buf[sizeof(struct xfrm_algo) + 16];
		struct xfrm_algo *ea = (struct xfrm_algo *)alg_buf;

		memset(alg_buf, 0, sizeof(alg_buf));
		strncpy(ea->alg_name, "cbc(aes)", sizeof(ea->alg_name) - 1);
		ea->alg_key_len = 16 * 8;
		memset(ea->alg_key, 0xbb, 16);
		put_attr(nlh, XFRMA_ALG_CRYPT, alg_buf, sizeof(alg_buf));
	}
	{
		struct xfrm_encap_tmpl enc;

		memset(&enc, 0, sizeof(enc));
		enc.encap_type = UDP_ENCAP_ESPINUDP;
		enc.encap_sport = htons(ENC_PORT);
		enc.encap_dport = htons(ENC_PORT);
		put_attr(nlh, XFRMA_ENCAP, &enc, sizeof(enc));
	}

	if (send(sk, nlh, nlh->nlmsg_len, 0) < 0)
		goto fail;
	n = recv(sk, rbuf, sizeof(rbuf), 0);
	if (n < 0)
		goto fail;
	if (((struct nlmsghdr *)rbuf)->nlmsg_type == NLMSG_ERROR) {
		struct nlmsgerr *e = NLMSG_DATA((struct nlmsghdr *)rbuf);

		if (e->error) {
			errno = -e->error;
			goto fail;
		}
	}
	close(sk);
	return 0;

fail:
	close(sk);
	return -1;
}

static int bind_udp6(const char *addr, int port)
{
	int sk;
	int one = 1;
	struct sockaddr_in6 sa;
	int enc = UDP_ENCAP_ESPINUDP;

	sk = socket(AF_INET6, SOCK_DGRAM, 0);
	if (sk < 0)
		die("socket");
	setsockopt(sk, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
	if (setsockopt(sk, IPPROTO_UDP, UDP_NO_CHECK6_RX, &one, sizeof(one)) < 0)
		die("setsockopt UDP_NO_CHECK6_RX");
	memset(&sa, 0, sizeof(sa));
	sa.sin6_family = AF_INET6;
	sa.sin6_port = htons(port);
	if (inet_pton(AF_INET6, addr, &sa.sin6_addr) != 1)
		die("inet_pton bind");
	if (bind(sk, (struct sockaddr *)&sa, sizeof(sa)) < 0)
		die("bind");
	if (setsockopt(sk, IPPROTO_UDP, UDP_ENCAP, &enc, sizeof(enc)) < 0)
		die("setsockopt UDP_ENCAP");
	return sk;
}

int main(int argc, char **argv)
{
	const char *src = argc > 1 ? argv[1] : "fd00:1::1";
	const char *dst = argc > 2 ? argv[2] : "fd00:1::2";
	int encap_sk;

	if (add_xfrm_sa(src, dst, 0xdeadbe10) < 0)
		die("add_xfrm_sa");
	encap_sk = bind_udp6(dst, ENC_PORT);
	printf("receiver-ready src=%s dst=%s encap=%d\n", src, dst, encap_sk);
	fflush(stdout);
	for (;;)
		sleep(60);
}
