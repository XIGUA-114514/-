#!/usr/bin/env python3
"""跑 DirtyAH6 之前的只读校验：确认 PoC 记录里的目标块与本机 /etc/pam.d/su 一致。

这个脚本不修改任何东西，只读文件、对比字节。
"""

import sys

TARGET = "/etc/pam.d/su"
OFFSET = 146
EXPECT = bytes.fromhex("70616d5f726f6f746f6b2e736f0a0a23")


def main() -> int:
    try:
        with open(TARGET, "rb") as fh:
            data = fh.read()
    except OSError as exc:
        print(f"[FAIL] 无法读取 {TARGET}: {exc}")
        return 1

    if len(data) < OFFSET + len(EXPECT):
        print(f"[FAIL] 文件只有 {len(data)} 字节，不足 {OFFSET + len(EXPECT)}")
        return 1

    actual = data[OFFSET:OFFSET + len(EXPECT)]

    print(f"file     : {TARGET}")
    print(f"size     : {len(data)} bytes")
    print(f"offset   : {OFFSET} (0x{OFFSET:x})")
    print(f"expect   : {EXPECT.hex()}")
    print(f"         : {EXPECT!r}")
    print(f"actual   : {actual.hex()}")
    print(f"         : {actual!r}")

    if actual == EXPECT:
        print("\n[OK] 目标块匹配 —— PoC 记录可用于本机，可以试跑")
        return 0

    print("\n[FAIL] 目标块不匹配 —— 不要跑 PoC，需要重算 OFFSET 与 EXPECT")
    print("       用 grep -abo 'pam_rootok.so' /etc/pam.d/su 取新的偏移")
    return 1


if __name__ == "__main__":
    sys.exit(main())
